Angel URIOT
Arthur AZAMBRE
Guillaume DESCOMPS

Assignment: 6

Notes: Run build_vs.bat to build a Visual Studio solution
