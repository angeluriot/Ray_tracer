#include "light/Light.hpp"
#include "light/Ray.hpp"
#include "light/Hit.hpp"
