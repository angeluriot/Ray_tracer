#include "crt.h"
#include "content.h"

namespace YAML
{
	Content::Content()
	{
	}

	Content::~Content()
	{
	}
}
