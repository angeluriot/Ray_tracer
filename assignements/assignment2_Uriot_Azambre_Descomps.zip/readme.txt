Angel URIOT
Arthur AZAMBRE
Guillaume DESCOMPS

Assignment: 1

Notes: Run build_vs.bat to build a Visual Studio solution
